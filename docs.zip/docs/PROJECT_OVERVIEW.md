# Project Overview – Hybrid Esports

## Summary
Hybrid Esports is a mobile UI/UX concept for discovering and managing tournaments across esports and mind-game categories. The supplied screens show home/discovery, tournament browsing, registration, event tracking, login, and profile settings.

## Problem statement
Players may have to search across different services to find tournaments for different games. They may also lack one convenient place to review registered events and event details.

## Proposed design direction
Explore a unified mobile interface where players can browse game categories, view tournament information, register, and revisit upcoming or past events.

## Categories shown
- Esports: Free Fire Max and BGMI
- Other games: Chess and Checkers

## Key screens
1. Login
2. Home and tournament discovery
3. Tournament list and mode selection
4. Tournament registration
5. Registration confirmation
6. My Events (upcoming and past)
7. Profile and settings

## Scope boundary
This repository documents UI/UX screens and a Figma prototype. It does not claim that authentication, payments, tournament scheduling, room credentials, or database functionality are implemented.
