# Design Process

## 1. Understand the problem
The concept addresses two needs: finding tournaments for different games in one place, and keeping track of tournaments a player has registered for.

## 2. Define the main user journey
The supplied screens suggest this high-level flow:
1. Open the app and browse featured tournaments or game categories.
2. Select a game and tournament mode.
3. Review tournament information.
4. Enter player/game details and register.
5. Review the registration confirmation.
6. Find the event later in My Events and check its details.

A separate account flow includes login and profile/settings.

## 3. Structure the interface
- Discovery: search, featured tournament, game categories.
- Tournament participation: tournament listing, mode, registration, confirmation.
- Event management: upcoming events, past events, check-in.
- Account: login, profile, preferences, notifications, terms, logout.

## 4. Visual design direction
The supplied screens use a dark purple/blue gradient background, bright cyan/blue accents, card-based tournament sections, prominent labels and buttons, and a bottom navigation bar.

## 5. Prototype and review
The screens are linked in a Figma prototype. Review the path from home to registration and then to My Events from the perspective of a first-time user.

## 6. Recommended next iteration
- Correct spelling and grammar in labels and messages.
- Improve consistency in text contrast, font sizes, alignment, and spacing.
- Clarify blank or missing values in the registration confirmation.
- Add error, loading, empty, and success states.
- Test the flows with players and record their feedback.

## Design ownership note
Describe only work personally completed. If research, testing, assets, or screens were contributed by someone else or generated with a tool, disclose that accurately in the portfolio presentation.
